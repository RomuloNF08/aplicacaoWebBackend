package com.stefanini.aplicacaoWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacaoWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
