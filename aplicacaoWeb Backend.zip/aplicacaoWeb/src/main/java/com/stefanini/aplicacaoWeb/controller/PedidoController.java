package com.stefanini.aplicacaoWeb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.stefanini.aplicacaoWeb.model.Pedido;
import com.stefanini.aplicacaoWeb.service.PedidoService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {
    @Autowired
    private PedidoService pedidoService;

    @GetMapping
    public List<Pedido> getAllPedidos() {
        return pedidoService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pedido> getPedidoById(@PathVariable Integer id) {
        Optional<Pedido> pedido = pedidoService.findById(id);
        return pedido.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Pedido createPedido(@RequestBody Pedido pedido) {
        Pedido savedPedido = pedidoService.save(pedido);
        double imposto = pedidoService.calcularImposto(savedPedido);
        System.out.println("Imposto sobre a compra: " + imposto);
        return savedPedido;
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pedido> updatePedido(@PathVariable Integer id, @RequestBody Pedido pedidoDetails) {
        Optional<Pedido> optionalPedido = pedidoService.findById(id);
        if (optionalPedido.isPresent()) {
            Pedido pedido = optionalPedido.get();
            pedido.setNomeCliente(pedidoDetails.getNomeCliente());
            pedido.setTipoCliente(pedidoDetails.getTipoCliente());
            pedido.setCnpjCpf(pedidoDetails.getCnpjCpf());
            pedido.setDataCompra(pedidoDetails.getDataCompra());
            pedido.setValorTotal(pedidoDetails.getValorTotal());
            pedido.setItem(pedidoDetails.getItem());
            Pedido updatedPedido = pedidoService.save(pedido);
            double imposto = pedidoService.calcularImposto(updatedPedido);
            System.out.println("Imposto sobre a compra: " + imposto);
            return ResponseEntity.ok(updatedPedido);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePedido(@PathVariable Integer id) {
        if (pedidoService.findById(id).isPresent()) {
            pedidoService.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
