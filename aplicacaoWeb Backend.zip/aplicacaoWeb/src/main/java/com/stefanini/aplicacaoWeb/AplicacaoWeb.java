package com.stefanini.aplicacaoWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicacaoWeb {
	
	public static void main(String[] args) {
		SpringApplication.run(AplicacaoWeb.class, args);
	}
}
