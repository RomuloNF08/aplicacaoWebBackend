package com.stefanini.aplicacaoWeb.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stefanini.aplicacaoWeb.model.Pedido;
import com.stefanini.aplicacaoWeb.repository.PedidoRepository;

import jakarta.transaction.Transactional;

@Service
public class PedidoService {
    @Autowired
    private PedidoRepository pedidoRepository;

    @Transactional
    public Pedido save(Pedido pedido) {
        return pedidoRepository.save(pedido);
    }

    public List<Pedido> findAll() {
        return pedidoRepository.findAll();
    }

    public Optional<Pedido> findById(Integer id) {
        return pedidoRepository.findById(id);
    }

    @Transactional
    public void deleteById(Integer id) {
        pedidoRepository.deleteById(id);
    }

    public double calcularImposto(Pedido pedido) {
        if ("Pessoa Física".equals(pedido.getTipoCliente())) {
            return pedido.getValorTotal() * 0.052;
        } else if ("Pessoa Jurídica".equals(pedido.getTipoCliente())) {
            return 1 + (pedido.getValorTotal() * 0.032);
        }
        return 0;
    }
}
