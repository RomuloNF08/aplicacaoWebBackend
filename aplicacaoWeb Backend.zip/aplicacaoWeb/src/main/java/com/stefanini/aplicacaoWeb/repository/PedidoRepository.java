package com.stefanini.aplicacaoWeb.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stefanini.aplicacaoWeb.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

	Optional<Pedido> findById(Integer id);

	void deleteById(Integer id);
}
