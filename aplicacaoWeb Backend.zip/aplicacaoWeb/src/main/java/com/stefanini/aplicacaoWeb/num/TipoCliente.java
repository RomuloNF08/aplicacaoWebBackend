package com.stefanini.aplicacaoWeb.num;

public enum TipoCliente {
	PESSOA_FISICA, PESSOA_JURIDICA
}
